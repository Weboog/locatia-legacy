create procedure add_owner(IN owner_name varchar(30), IN phone varchar(10))
BEGIN
		insert into owners (owners.`name`, owners.`phone`) values (owner_name, phone);
	END;

